<?php

defined('ABSPATH') or die('No script kiddies please!');

JLoader::import('adapter.payment.payment');


class AbstractKashierPayment extends JPayment{
	
	
	protected function buildAdminParameters() {
		$logo_img = VIKKASHIER_URI . 'kashier-logo.png';

        ?>
        <script>
            var eachProductContent
            jQuery(document).ready(function ($) {

            const isAdvancedOptionsChecked = $($("select[name='vikpaymentparams[advancedoptions]']")[0]).find('option:selected')
                                              ? $($("select[name='vikpaymentparams[advancedoptions]']")[0]).find('option:selected').val() : 'NO'       
           
            const currencyConverter = $($("select[name='vikpaymentparams[enforceegppayment]']")[0]).parent().parent()
            const currencyExchangeRates = $($("input[name='vikpaymentparams[exchangerate]']")[0]).parent().parent()

            if (isAdvancedOptionsChecked == 'Yes') {
                $(currencyConverter).show();
                $(currencyExchangeRates).show();
            } else {
                $(currencyConverter).hide();
                $(currencyExchangeRates).hide();
            }
            $('#wpcontent').prepend(
                "<div id='kashier-error' style='position: fixed;right: -600px;transition: right 1.5s;top: 150px;background-color: #FF9494;line-height:30px;color: aliceblue; width:450px; height:30px; border: 1px solid #ccc9; border-radius:6px; padding:5px;box-shadow:0 3px 8px #33333361'></div>"
            );

            $('#jbutton-updatepayment').click(function (e) {
                if (isAdvancedOptionsChecked == 'Yes') {
                if ($($("input[name='vikpaymentparams[exchangerate]']")[0]).val() <= 1) {
                    $('#kashier-error').text('Exhange rates must be greater than 1');
                    $('#kashier-error').css('right', '50px');

                    setTimeout(() => {
                    $('#kashier-error').css('right', '-600px');
                    }, 5000);
                    e.StopPropagation();

                    return false;
                }
                return true;
                }
            });

            $($("select[name='vikpaymentparams[advancedoptions]']")[0]).change(function () {
                if ($($("select[name='vikpaymentparams[advancedoptions]']")[0]).find('option:selected').val() == 'Yes') {
                   $(currencyConverter).show();
                   $(currencyExchangeRates).show();
                } else {
                   $(currencyConverter).hide();
                   $(currencyExchangeRates).hide();
                }
            });
            });

        </script>
        <?php

        return array(	
            'logo' => array(
                'label' => __('','vikbooking'),
                'type' => 'custom',
                'html' => '<img src="'.$logo_img.'"/>'
            ),
            'paymentmethod' => array(
                'label' => __('Payment Method','vikkashier'),
                'type'  => 'select',
                'options'=> array('All Allowed Methods','Card','Bank Installments','Wallet')
            ),
            'merchantid' => array(
                'label' => __('Merchant ID','vikbooking'),
                'type' => 'text'
            ),
            'testmode' => array(
                'label' => __('Test Mode','vikbooking'),
                'type' => 'select',
                'options' => array('Yes', 'No'),
            ),
            'testapikey' => array(
                'label' => __('Test API Key','vikbooking'),
                'type' => 'text',
            ),
            'liveapikey' => array(
                'label' => __('Live API Key','vikbooking'),
                'type' => 'text',
            ),
            'advancedoptions' => array(
                'label'       => __('Advanced Options','vikkashier'),
                'type'        => 'select',
                'options'     => array('No', 'Yes'),
                'description' => __( 'Enable Advance Options','vikkashier'),
                'desc_tip'    => true,
                'default'     => 'No',
            ),
            'enforceegppayment'                       => array(
                'title'       => __('Enforce EGP Payment','VikKashier'),
                'label'       => __('Enforce EGP Payment, Convert to EGP','vikkashier'),
                'type' => 'select',
                'options' => array('No', 'Yes'),
                'description' => __('Enforce EGP payment. Regardless what is displayed currency on your website.','vikkashier'),
                'desc_tip'    => true,
                'default'     => 'No',
            ),
            'exchangerate'                         => array(
                'label'       => __('Currency Exchange Rate','VikKashier'),
                'type'        => 'text',
                'description' => __('The exchange rate from the default currency on your website to EGP.','vikkashier'),
                'default'     => '',
                'desc_tip'    => true,
            ),
            
        );

	}
	
	public function __construct($alias, $order, $params = array()) {
		parent::__construct($alias, $order, $params);
	}
	
	protected function beginTransaction() {

        $isEnableCurrencyConverterMode = $this->getParam('advancedoptions') == 'Yes' 
                                         && $this->getParam('enforceegppayment') == 'Yes' ? true : false;

        if($isEnableCurrencyConverterMode){
            $exchangeRates = $this->getParam('exchangerate');
            $amount = $this->get('total_to_pay') * $exchangeRates;
            $currency = 'EGP';
        } else {
            $amount = $this->get('total_to_pay');
            $currency = $this->get('transaction_currency');
        }

        $merchant_id = $this->getParam('merchantid');
        $mode = $this->getParam('testmode') == 'Yes' ? 'test' : 'live';
        $apikey = $mode == 'test' ? $this->getParam('testapikey') : $this->getParam('liveapikey');
        $merchant_order_id = $this->order->details['id'] . '-' . time();
	    $diplay_lang = strpos(get_bloginfo("language"),'ar') ? 'ar': 'en';
        $hash = $this->createHash($merchant_id,$merchant_order_id,$amount,$currency,$apikey);
        $paymentMethod = array('All Allowed Methods'=>'', 'Card'=> 'card' ,'Bank Installments'=>'bank_installments','Wallet'=>'wallet') ;
        $allowedMethod = $paymentMethod[$this->getParam('paymentmethod')];

                
        $metaData = json_encode(array(
            'OrderId' => $this->order->details['id'],
            'CustomerEmail' => $this->get('customer_email'),
            'CustomerPhone' => $this->order->details['phone'],
        ));

        // var_dump($this->order->details['id']);
        // var_dump($this->get('customer_email'));
        // var_dump($metaData);
        // exit();
        
        $action_url = "https://checkout.kashier.io/kashier-checkout.js";

        $notify_url = urlencode($this->get('notify_url'));



        $iframe ='<script id="kashier-iFrame" src="'.$action_url;
        $iframe.='" data-merchantId="'.$merchant_id;
        $iframe.='" data-amount="'.$amount;
        $iframe.='" data-currency="'.$currency;
        $iframe.='" data-orderId="'.$merchant_order_id;
        $iframe.='" data-hash="'.$hash;
        $iframe.='" data-allowedMethods="'.$allowedMethod;
        $iframe.='" data-display="'.$diplay_lang;
        $iframe.='" data-merchantRedirect="'.$notify_url;
        $iframe.='" data-metaData='.$metaData;
        $iframe.=' data-redirectMethod="post';
        $iframe.='" data-failureRedirect="true';
        $iframe.='" data-mode="'.$mode.'"></script>';
        $iframe.='<script>const kashierButton = document.getElementById("el-kashier-button");if(kashierButton){kashierButton.click();}</script>';
        
        echo $iframe;
	}
	
	protected function validateTransaction(JPaymentStatus &$status) {
		/** See the code below to build this method */
        $log = '';
	
        /** In case of error the log will be sent via email to the admin */

        $response = $_POST['paymentStatus'];

        $mode = $_POST['mode'];
        $apikey = $mode == 'test' ? $this->getParam('testapikey'): $this->getParam('liveapikey');


        if($this->checksignature($apikey)){

            /** Process your gateway response here */
            if($response == 'SUCCESS') {
                $status->verified(); 
                /** Set a value for the value paid */
                $status->paid( $_POST['amount']);
                $status->setData('TransactionId', $_POST['transactionId']);
                $status->setData('merchantOrderId', $_POST['merchantOrderId']);
            
                $status->appendLog( "Successful payment");
                $status->appendLog( "Transaction Id:- ".$_POST['transactionId']);
                $status->appendLog( "Merchant Order Id:- ".$_POST['merchantOrderId']);

            } else {

                $status->setData('TransactionId', $_POST['transactionId']);
                $status->setData('merchantOrderId', $_POST['merchantOrderId']);

                $status->appendLog( "Failure payment");
                $status->appendLog( "Transaction Error!:- ".$_POST['transaction']);
                $status->appendLog( "Merchant Order Error!:- :- ".$_POST['merchantOrderId']);
            }
            //stop iteration
            return true;
       } else if(!isset($_POST['signature'])) {
            $status->appendLog( "Failure payment");
            $status->appendLog( "Transaction Error!:- ".$_POST['transaction']);
            $status->appendLog( "Merchant Order Error!:- :- ".$_POST['merchantOrderId']);
       } else {
           exit('Invalid signature');
       }


	}



    protected function complete($res  = 0)
    {
        $app = JFactory::getApplication();

        if ($res)
        {
            $url = $this->get('return_url');

            // display successful message
            $app->enqueueMessage(__('Thank you! Payment successfully received.', 'vikkashier'));
        }
        else
        {
            $url = $this->get('error_url');

            // display error message
            $app->enqueueMessage(__('It was not possible to verify the payment. Please, try again.', 'vikkashier'));
            
        }

        JFactory::getApplication()->redirect($url);
        exit;
    }
    
    

    private function createHash($mid,$orderId,$amount,$currency,$secret){
        
        $path = "/?payment=".$mid.".".$orderId.".".$amount.".".$currency;
        $hash = hash_hmac( 'sha256' , $path , $secret ,false);
        return $hash;
    }

    private function checksignature($secret){
        $queryString = "";
        foreach ($_POST as $key => $value) {
            if($key == "signature" || $key== "mode"){
                continue;
            }
            $queryString = $queryString."&".$key."=".$value;
        }
        $queryString = ltrim($queryString, $queryString[0]);
        $signature = hash_hmac( 'sha256' , $queryString , $secret ,false);
        if($signature == $_POST["signature"]){
           return true;
        }else{
            return false;
        }
    }
}
?>